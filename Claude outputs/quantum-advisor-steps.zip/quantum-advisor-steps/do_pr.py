"""One command per pull request. Does all the git work for you.

    python do_pr.py setup          first time only: checks Python/Git, sets your name/email, downloads the repo
    python do_pr.py 0              Sourav only, once: uploads the original project to GitHub
    python do_pr.py <PR number>    builds your pull request: branch, every commit, tests, upload, opens GitHub
    python do_pr.py status         shows which pull requests are already merged

Run it from inside this folder (quantum-advisor-steps). Add --yes to skip the "press Enter" pauses.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import urllib.parse
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO_URL = os.environ.get("QA_REPO_URL", "https://github.com/sourav-singh-10/quantum-advisor")
YES = "--yes" in sys.argv
STEPS = sorted((HERE / "steps").iterdir())
PLAN = json.loads((HERE / "prs.json").read_text(encoding="utf-8"))


# ---------------------------------------------------------------- helpers
def say(msg=""):
    print(msg, flush=True)


def stop(msg):
    say("\n  !! " + msg)
    sys.exit(1)


def run(cmd, cwd=None, check=True, capture=False):
    r = subprocess.run(cmd, cwd=cwd, text=True, capture_output=capture)
    if check and r.returncode != 0:
        if capture:
            say(r.stdout + r.stderr)
        stop("this command failed: " + " ".join(map(str, cmd)))
    return (r.stdout or "").strip() if capture else r.returncode


def git(*args, cwd, capture=True, check=True):
    return run(["git", *args], cwd=cwd, capture=capture, check=check)


def pause(msg):
    if not YES:
        input(f"\n  >> {msg} [press Enter] ")


def is_our_remote(folder: Path) -> bool:
    url = git("remote", "get-url", "origin", cwd=folder, check=False).strip().rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    return bool(url) and ("quantum-advisor" in url.lower() or url == REPO_URL)


def find_repo() -> Path:
    for i, a in enumerate(sys.argv):
        if a == "--repo" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1]).resolve()
    for base in (HERE.parent, HERE.parent.parent):
        for d in sorted(base.iterdir()):
            if d.is_dir() and d != HERE and (d / ".git").exists() and is_our_remote(d):
                return d
    stop("could not find your quantum-advisor folder next to this one. Run: python do_pr.py setup")


def venv_python(repo: Path) -> str:
    win = repo / "venv" / "Scripts" / "python.exe"
    nix = repo / "venv" / "bin" / "python"
    if not win.exists() and not nix.exists():
        say("  creating a private Python environment (venv) in your repo folder ...")
        run([sys.executable, "-m", "venv", str(repo / "venv")])
    return str(win if win.exists() else nix)


def install_requirements(repo: Path):
    py = venv_python(repo)
    say("  installing the project's libraries (first time takes a few minutes) ...")
    req = "requirements-dev.txt" if (repo / "requirements-dev.txt").exists() else "requirements.txt"
    if not (repo / req).exists():
        stop(f"{req} is missing in {repo}; is this the right folder?")
    run([py, "-m", "pip", "install", "-q", "--disable-pip-version-check", "-r", req], cwd=repo)
    run([py, "-m", "pip", "install", "-q", "--disable-pip-version-check", "pytest"], cwd=repo)


def run_tests(repo: Path) -> tuple[bool, str]:
    py = venv_python(repo)
    r = subprocess.run([py, "-m", "pytest", "-q", "-p", "no:cacheprovider"], cwd=repo,
                       text=True, capture_output=True)
    lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
    return r.returncode == 0, (lines[-1] if lines else r.stderr[-300:])


def apply_step(repo: Path, step: dict, step_dir: Path):
    import glob
    for old, new in step["rename"]:
        (repo / new).parent.mkdir(parents=True, exist_ok=True)
        git("mv", old, new, cwd=repo)
    for path in step["delete"]:
        git("rm", "-q", "-r", "--ignore-unmatch", path, cwd=repo)
    for pattern in step.get("delete_globs", []):
        for path in glob.glob(str(repo / pattern)):
            git("rm", "-q", "--ignore-unmatch", os.path.relpath(path, repo), cwd=repo)
    for f in step["files"]:
        dst = repo / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(step_dir / "files" / f, dst)


def check_identity(cwd):
    name = git("config", "user.name", cwd=cwd, check=False)
    email = git("config", "user.email", cwd=cwd, check=False)
    if not name or not email:
        stop("Git doesn't know who you are yet. Run: python do_pr.py setup")
    return name, email


def merged_messages(repo: Path) -> set[str]:
    git("fetch", "-q", "origin", cwd=repo, check=False)
    log = git("log", "origin/main", "--format=%s", cwd=repo, check=False)
    return set(log.splitlines())


# ---------------------------------------------------------------- commands
def cmd_setup():
    say("== Checking your computer ==")
    if sys.version_info < (3, 11):
        stop(f"you have Python {sys.version.split()[0]}; install Python 3.12 from python.org "
             "(tick 'Add python.exe to PATH'), then run this again.")
    say(f"  Python {sys.version.split()[0]} ok")
    if shutil.which("git") is None:
        stop("Git is not installed. Install it from https://git-scm.com/download/win "
             "(keep all the default options), close this window, open a new one, run again.")
    say("  " + run(["git", "--version"], capture=True) + " ok")

    name = run(["git", "config", "--global", "user.name"], capture=True, check=False)
    email = run(["git", "config", "--global", "user.email"], capture=True, check=False)
    if not name or not email:
        say("\nGit needs your name and the email you use on GitHub")
        say("(GitHub -> your photo -> Settings -> Emails shows it). Your commits are counted by this email.")
        name = input("  Your full name: ").strip()
        email = input("  Your GitHub email: ").strip()
        run(["git", "config", "--global", "user.name", name])
        run(["git", "config", "--global", "user.email", email])
    say(f"  you will commit as: {name} <{email}>")

    existing = [d for base in (HERE.parent, HERE.parent.parent) for d in base.iterdir()
                if d.is_dir() and (d / ".git").exists()]
    if any(is_our_remote(d) for d in existing):
        say("\n  your repo folder already exists next to this one.")
        return
    say("\n== Downloading the project from GitHub ==")
    say("  (if a GitHub sign-in window opens, sign in with YOUR account)")
    repo = HERE.parent / "quantum-advisor"
    run(["git", "clone", REPO_URL + ".git", str(repo)])
    if not git("rev-parse", "--verify", "--quiet", "HEAD", cwd=repo, check=False):
        shutil.rmtree(repo, ignore_errors=True)
        stop("the GitHub repo is still empty. Sourav must first run: python do_pr.py 0 "
             "(teammates: wait for Sourav, then run setup again).")
    install_requirements(repo)
    say(f"\nDone. Your project folder is {repo}")
    say("Next: wait until it's your turn in TEAM_PLAN.md, then run: python do_pr.py <your PR number>")


def cmd_first_push():
    repo = find_repo_for_first_push()
    check_identity(repo)
    if (repo / ".git").exists() and git("rev-parse", "--verify", "HEAD", cwd=repo, check=False):
        stop("this folder already has commits; the first upload was done already.")
    say(f"== Uploading the original project from {repo} ==")
    git("init", "-q", cwd=repo)
    git("add", ".", cwd=repo)
    git("commit", "-q", "-m", "chore: import CA2 baseline of Quantum Advisor", cwd=repo)
    git("branch", "-M", "main", cwd=repo)
    if not git("remote", cwd=repo):
        git("remote", "add", "origin", REPO_URL + ".git", cwd=repo)
    say("  uploading (a GitHub sign-in window may open: sign in as sourav-singh-10) ...")
    git("push", "-u", "origin", "main", cwd=repo, capture=False)
    install_requirements(repo)
    say(f"\nDone. Check {REPO_URL} - you should see your files.")
    say("Next: python do_pr.py 1")


def find_repo_for_first_push() -> Path:
    for i, a in enumerate(sys.argv):
        if a == "--repo" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1]).resolve()
    candidates = [d for base in (HERE.parent, HERE.parent.parent) for d in base.iterdir()
                  if d.is_dir() and d != HERE and (d / "app.py").exists()]
    if len(candidates) != 1:
        stop("put this folder next to your project folder (the one with app.py), "
             "or run: python do_pr.py 0 --repo \"C:\\path\\to\\project\"")
    return candidates[0]


def cmd_status():
    repo = find_repo()
    done = merged_messages(repo)
    say("PR  status   author    branch")
    for pr in PLAN:
        msgs = [c["message"] for c in pr["commits"]]
        state = "merged" if all(m in done for m in msgs) else "partial" if any(m in done for m in msgs) else "todo"
        say(f"{pr['number']:>2}  {state:8} {pr['author']:9} {pr['branch']}")


def cmd_pr(num: int):
    pr = next((p for p in PLAN if p["number"] == num), None)
    if not pr:
        stop(f"there is no PR {num}; see TEAM_PLAN.md")
    repo = find_repo()
    name, email = check_identity(repo)
    say(f"== PR {num}: {pr['title']} ==")
    say(f"   planned author: {pr['author']}   you are: {name} <{email}>")
    pause("Is this your PR? (Ctrl+C to cancel)")

    if git("status", "--porcelain", "--untracked-files=no", cwd=repo):
        stop("you have unsaved changes in the repo folder. Ask the team lead before continuing.")
    git("checkout", "-q", "main", cwd=repo)
    git("pull", "-q", "origin", "main", cwd=repo, capture=False)

    done = merged_messages(repo)
    for earlier in PLAN:
        if earlier["number"] < num and not all(c["message"] in done for c in earlier["commits"]):
            stop(f"PR {earlier['number']} ({earlier['author']}) is not merged yet. "
                 "Wait for it - each PR builds on the one before.")
    if all(c["message"] in done for c in pr["commits"]):
        stop(f"PR {num} is already merged. Nothing to do.")

    branch = pr["branch"]
    exists = git("rev-parse", "--verify", "--quiet", branch, cwd=repo, check=False)
    git("checkout", "-q", *( [branch] if exists else ["-b", branch] ), cwd=repo)
    on_branch = set(git("log", "main.." + branch, "--format=%s", cwd=repo, check=False).splitlines())
    install_requirements(repo)

    results = []
    for c in pr["commits"]:
        step_dir = next(d for d in STEPS if d.name.startswith(f"{c['step']:02d}-"))
        step = json.loads((step_dir / "step.json").read_text(encoding="utf-8"))
        if c["message"] in on_branch:
            say(f"\n-- step {c['step']:02d} already committed, skipping")
            continue
        say(f"\n-- step {c['step']:02d}: {c['message']}")
        apply_step(repo, step, step_dir)
        git("add", "-A", cwd=repo)
        say(git("status", "--short", cwd=repo))
        if any(f.startswith("requirements") for f in step["files"]):
            install_requirements(repo)
        ok, line = run_tests(repo)
        expected = step["expected_tests"].split(" in ")[0]
        say(f"   tests: {line}   (expected: {expected})")
        if not ok or not line.startswith(expected):
            stop("tests did not match. Don't push; send this whole window's text to Sourav / Claude.")
        say("   Open these files in VS Code and read them; TEAM_PLAN.md says what you must be able to explain.")
        pause("Commit this step?")
        git("commit", "-q", "-m", c["message"], cwd=repo)
        results.append(f"- `{c['message']}` → {line}")

    say("\n== Uploading your branch to GitHub ==")
    git("push", "-u", "origin", branch, cwd=repo, capture=False)
    body = (f"Part of the CA3 redesign (PR {num} in TEAM_PLAN.md).\n\n**Commits and test results**\n"
            + "\n".join(results or ["(already pushed)"]) +
            f"\n\nReviewer: {pr['reviewer']} — please read *Files changed*, leave a comment, then approve.")
    url = (f"{REPO_URL}/compare/main...{branch}?expand=1&"
           + urllib.parse.urlencode({"title": pr["title"], "body": body}))
    say("\nLast part is on the website. Opening it now:")
    say("  1. Click the green 'Create pull request' button.")
    say(f"  2. On the right, 'Reviewers' -> pick {pr['reviewer']}.")
    say("  3. When they approve: 'Merge pull request' -> 'Confirm merge'.")
    say(f"\n  If the browser didn't open, paste this link:\n  {url}")
    webbrowser.open(url)


if __name__ == "__main__":
    args, skip = [], False
    for a in sys.argv[1:]:
        if skip:
            skip = False
        elif a == "--repo":
            skip = True
        elif not a.startswith("--"):
            args.append(a)
    if not args:
        say(__doc__); sys.exit(0)
    a = args[0]
    if a == "setup":
        cmd_setup()
    elif a == "status":
        cmd_status()
    elif a == "0":
        cmd_first_push()
    elif a.isdigit():
        cmd_pr(int(a))
    else:
        say(__doc__)
