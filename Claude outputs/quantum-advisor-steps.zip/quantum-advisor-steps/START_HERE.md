# Start here — Git and GitHub for this project, in plain words

You don't need to learn Git. A helper script (`do_pr.py`) does all the Git work. You will:
1. type **one command** when it's your turn, and
2. click **three buttons** on the GitHub website.

## The 6 words you'll see

| Word | What it means here |
|---|---|
| **Repository (repo)** | The project folder that lives on GitHub: `github.com/sourav-singh-10/quantum-advisor` |
| **Commit** | A saved checkpoint of changes, with a short message and **your name on it**. This is what CA3 counts. |
| **Branch** | A separate copy where you make your changes without touching the main version (`main`). |
| **Push** | Upload your branch to GitHub. |
| **Pull request (PR)** | "Please add my branch to `main`": a page on GitHub where a teammate checks your changes. |
| **Review → Merge** | A teammate reads it and clicks *Approve*; then the author clicks *Merge*, and the changes join `main`. |

## 1. Install (once, ~10 minutes)

1. **GitHub account**: sign up at https://github.com if you don't have one. Send your **username** to Sourav.
2. **Python 3.12**: https://www.python.org/downloads/ → run the installer → **tick "Add python.exe to PATH"** at the bottom of the first screen.
3. **Git**: https://git-scm.com/download/win → run the installer → keep clicking *Next* (the defaults are fine).
4. *(Recommended)* **VS Code** to read the code: https://code.visualstudio.com

## 2. Get access (once)

- **Sourav**: GitHub → your repo → **Settings** → **Collaborators** → **Add people** → type each teammate's username.
- **Teammates**: open the invitation email from GitHub → **Accept invitation**.

## 3. Put the folder in the right place (once)

Unzip `quantum-advisor-steps.zip`.

- **Sourav**: put `quantum-advisor-steps` in `C:\Users\soura\Downloads\Quantum-Advisor-main\`, **next to** the project folder (not inside it):
  ```
  Downloads\Quantum-Advisor-main\
      Quantum-Advisor-main\        <- the project (has app.py)
      quantum-advisor-steps\       <- this folder
  ```
- **Teammates**: put it anywhere simple, e.g. `Documents\CA3\quantum-advisor-steps\`. The setup command downloads the project next to it.

## 4. Open a terminal in that folder

Open `quantum-advisor-steps` in File Explorer → click the **address bar** at the top → type `powershell` → press **Enter**. A blue/black window opens already inside the folder. Every command below is typed there.

## 5. First-time command

- **Teammates**: `python do_pr.py setup`
  It checks Python and Git, asks your **name** and your **GitHub email** (GitHub → your photo → Settings → Emails), and downloads the project. If a GitHub window pops up, click **Sign in with your browser** and sign in as **yourself**.
- **Sourav**: `python do_pr.py 0`
  It uploads the original project to GitHub (sign in as `sourav-singh-10` if asked).

## 6. When it's your turn: one command

```
python do_pr.py <your PR number>
```

Check whose turn it is with `python do_pr.py status`. PRs go in order 1 → 11; the script refuses to run yours before the earlier ones are merged.

What happens:
- It makes your branch, then goes through your steps one by one.
- At each step it **shows which files changed and runs the tests** (e.g. `35 passed`). Then it **pauses**.
- **Use the pause.** Open those files in VS Code and read them, together with the *What to explain* notes for your PR in `TEAM_PLAN.md`. In the presentation you'll be asked about your part.
- Press **Enter** and it saves the commit with your name. Then it moves to the next step.
- At the end it uploads your branch and **opens GitHub in your browser**.

## 7. On the website: three clicks

**If you are the author:**
1. Click the green **Create pull request** button. The title and description are already filled in.
2. On the right side, click **Reviewers** ⚙ and pick the reviewer named in `TEAM_PLAN.md`.
3. When they've approved, click **Merge pull request** → **Confirm merge**. Tell the next person it's their turn.

**If you are the reviewer** (GitHub emails you):
1. Open the pull request → **Files changed** tab.
2. Read it. Hover over any line → click the blue **+** → write a real comment or question (e.g. "Why is the retry limit 1?") → **Start a review**.
3. Top right: **Finish your review** → choose **Approve** → **Submit review**.

Reviews and comments count toward your CA3 marks too.

## If something goes wrong

- The script stops with `!!` and a message. **Don't try commands from the internet** (especially anything with `--force`). Copy the whole window's text and send it to Sourav, who can paste it to Claude.
- "tests did not match": nothing was uploaded. Just send the text.
- Closed the window halfway? Run the same `python do_pr.py <number>` again; it skips the steps already done.

## Rules that protect your marks

- Only run **your own** PR numbers, on **your own** laptop, signed in as **you**.
- Do it on the day you actually do it. Different days for different PRs is good: "active days" are 25% of the score.
- Read your code. Using AI is allowed in CA3; not understanding your own part is not.
