# Quantum Advisor — Team Plan for CA3

**11 pull requests / 36 small commits.** Every step was tested in order: `main` stays green after every merge, and the last step leaves the complete project. Split by contribution: Sourav (Member 1) about 35% (core, orchestration, API), and about 22% each for Member 2 (data tools + analyst agents), Member 3 (schemas + decision agents) and Member 4 (frontend + documentation).

> **Integrity.** CA3 allows AI tools but you must *understand and defend* what you commit. Read each diff (`git diff`) and the notes under *What to explain* before committing. Commit only under your own GitHub login, on the day you actually do it: never backdate, never commit for someone else. Say in the presentation that an AI assistant helped, and show you understand the code.

> **Section G is normalised against the top contributor.** Whoever commits most gets the full 5 marks; everyone else is scored relative to them. Agree this split with your team.

## How to do your part

**Read `START_HERE.md` first.** In short: install Python 3.12 and Git, open a terminal in this folder, then:

| Who | First time | When it's your turn |
|---|---|---|
| Sourav | `python do_pr.py 0` (uploads the original project) | `python do_pr.py <PR number>` |
| Teammates | `python do_pr.py setup` (name, email, downloads the repo) | `python do_pr.py <PR number>` |

The script makes the branch, applies each step, runs the tests, pauses so you can read the changes, commits under your name, uploads, and opens the pull-request page. You then click **Create pull request**, pick the reviewer, and after approval **Merge pull request**. `python do_pr.py status` shows what's merged.

*Manual alternative:* `apply_step.py <step>` applies a single step if you prefer to run the git commands yourself.

## The 11 pull requests

| PR | Day | Author | Branch | Title | Steps | Reviewer |
|---|---|---|---|---|---|---|
| 1 | 1 | Member 1 — Sourav (lead) | `chore/repo-hygiene` | Repository hygiene and CI | 1–3 | Member 4 |
| 2 | 1 | Member 1 — Sourav (lead) | `feat/core-infra` | Core infrastructure: config, LLM client, tracer, memory | 4–7 | Member 3 |
| 3 | 2 | Member 3 | `feat/decision-core` | Typed schemas and risk / position maths | 8–10 | Member 2 |
| 4 | 2 | Member 2 | `feat/data-tools` | Data tools: prices, indicators, fundamentals, news | 11–15 | Member 3 |
| 5 | 3 | Member 1 — Sourav (lead) | `feat/base-agent` | BaseAgent: LLM decisions with rule fallback and a tool loop | 16 | Member 2 |
| 6 | 3 | Member 2 | `feat/analyst-agents` | Market, Fundamentals and News analyst agents | 17–19 | Member 4 |
| 7 | 4 | Member 3 | `feat/committee-agents` | Profile, Risk, Strategy, Portfolio and Report agents | 20–23 | Member 2 |
| 8 | 4 | Member 1 — Sourav (lead) | `feat/planner-graph` | Planner and LangGraph orchestration | 24–26 | Member 3 |
| 9 | 5 | Member 1 — Sourav (lead) | `feat/api-switch` | Serve the agent graph from the API and retire the CA2 pipeline | 27–29 | Member 4 |
| 10 | 5 | Member 4 | `feat/live-agent-ui` | Live agent conversation in the UI | 30–32 | Member 1 — Sourav (lead) |
| 11 | 6 | Member 4 | `docs/submission` | JSON Schemas, documentation and deployment | 33–36 | Member 1 — Sourav (lead) |

Commits per person: Member 1 — Sourav (lead): 14, Member 2: 8, Member 3: 7, Member 4: 7. Everyone also reviews PRs and captures one live trace (below).

Days are a suggestion. Spreading work over real, separate days raises the *active days* score (25%).

## Every commit

| Step | PR | Who | Commit message | Expected `python -m pytest -q` |
|---|---|---|---|---|
| 01 | 1 | M1 | `chore: remove generated reports, unused services and stale logs` | 8 passed |
| 02 | 1 | M1 | `chore: pin dependencies, add .env.example and line-ending rules` | 8 passed |
| 03 | 1 | M1 | `ci: run pytest on every push and pull request` | 8 passed |
| 04 | 2 | M1 | `refactor: move the CA2 pipeline into legacy/ while the redesign lands` | 8 passed |
| 05 | 2 | M1 | `feat(config): central configuration for keys, models and agent limits` | 8 passed |
| 06 | 2 | M1 | `feat(llm): structured Gemini client with schema validation, retry and free-tier rate limit` | 13 passed |
| 07 | 2 | M1 | `feat(core): message-level tracer, run memory and per-run context` | 19 passed |
| 08 | 3 | M3 | `feat(schemas): request validation and typed schemas for every LLM decision` | 27 passed |
| 09 | 3 | M3 | `feat(tools): risk capacity, stock risk score and suitability gap` | 31 passed |
| 10 | 3 | M3 | `feat(tools): volatility-scaled price targets and position sizing` | 35 passed |
| 11 | 4 | M2 | `feat(tools): price history from yfinance, Alpha Vantage and MarketStack with caching` | 42 passed |
| 12 | 4 | M2 | `feat(tools): RSI, volatility and moving-average trend indicators` | 47 passed |
| 13 | 4 | M2 | `feat(tools): real fundamentals from yfinance with a transparent health score` | 50 passed |
| 14 | 4 | M2 | `feat(tools): Google News RSS and NewsAPI headlines with a whole-word sentiment fallback` | 55 passed |
| 15 | 4 | M2 | `refactor: move the portfolio analyzer to tools/` | 55 passed |
| 16 | 5 | M1 | `feat(agents): BaseAgent with structured decisions, rule fallback and a ReAct-style tool loop` | 59 passed |
| 17 | 6 | M2 | `feat(agents): market analyst chooses and switches price sources` | 62 passed |
| 18 | 6 | M2 | `feat(agents): fundamentals analyst interprets real ratios` | 64 passed |
| 19 | 6 | M2 | `feat(agents): news analyst picks a source and labels each headline` | 67 passed |
| 20 | 7 | M3 | `feat(agents): profile agent turns the investor's goal into constraints` | 69 passed |
| 21 | 7 | M3 | `feat(agents): risk manager critiques drafts with numbered objections and a guardrail` | 75 passed |
| 22 | 7 | M3 | `feat(agents): strategy agent answers each objection by id` | 78 passed |
| 23 | 7 | M3 | `feat(agents): portfolio sizing from the real portfolio and a report that explains the debate` | 81 passed |
| 24 | 8 | M1 | `feat(agents): planner plans, re-plans failed work and arbitrates deadlocks` | 81 passed |
| 25 | 8 | M1 | `feat(core): LangGraph state machine with re-plan and Strategy-Risk debate loops` | 81 passed |
| 26 | 8 | M1 | `test: end-to-end agent paths with a scripted LLM` | 91 passed |
| 27 | 9 | M1 | `feat(api): validated analysis on the agent graph, live stream, trace and history endpoints, salted passwords` | 91 passed |
| 28 | 9 | M1 | `test(api): validation, streaming, trace endpoint, auth and graceful failure` | 102 passed |
| 29 | 9 | M1 | `refactor: remove the legacy CA2 pipeline` | 94 passed |
| 30 | 10 | M4 | `refactor(frontend): split index.html into html, css and js files` | 94 passed |
| 31 | 10 | M4 | `fix(frontend): remove the hard-coded price engine and the 5-second silent fallback` | 94 passed |
| 32 | 10 | M4 | `feat(frontend): stream the agents' conversation live and show findings, debate and report` | 94 passed |
| 33 | 11 | M4 | `feat(schemas): JSON Schemas for request, response and trace, checked against real output` | 97 passed |
| 34 | 11 | M4 | `docs: synopsis, design document, I/O definitions and architecture diagram` | 97 passed |
| 35 | 11 | M4 | `docs: rewrite README for the multi-agent system` | 97 passed |
| 36 | 11 | M4 | `chore(deploy): Render blueprint and a script to capture genuine run evidence` | 97 passed |

Step 01 also deletes `test_report_*.html` and the empty `frontend/style.css` from the original upload; the script does it.

## After PR 11: deploy and capture evidence (everyone)

1. **Sourav:** on Render, create a **Web Service** from `sourav-singh-10/quantum-advisor` (or point the existing service at it). Render reads `render.yaml`. In *Environment* add `GEMINI_API_KEY` (free: https://aistudio.google.com/apikey) and any optional data keys. Check `https://<app>.onrender.com/api/health?deep=1` shows `"llmAvailable": true`.
2. **Each member** signs up on the live site and captures one genuine run on a branch `evidence/<name>`:
   - Member 1: `--name normal --ticker TCS --age 30 --risk Aggressive --horizon Long-term --experience Experienced`
   - Member 2: `--name midcareer --ticker INFY --age 45 --risk Moderate --horizon Medium-term --experience Intermediate`
   - Member 3: `--name conflict --ticker ADANIENT --age 64 --risk Conservative --horizon Short-term --experience Beginner`
   - Member 4: `--name goal --ticker HDFCBANK --goal "House down-payment in 3 years"`
   ```
   python scripts/capture_run.py https://<app>.onrender.com you@example.com yourpassword <options>
   git add docs && git commit -m "docs(evidence): capture <name> run from the live deployment"
   ```
   Open a PR; someone else reviews. **Never edit these files.** Submit the trace that shows the most debate or re-planning.
3. Record the 2–3 minute backup demo video showing the live agent feed.

## What each person owns and must be able to explain

### Member 1 — Sourav (lead)

**Pull requests:** PR 1 (`chore/repo-hygiene`), PR 2 (`feat/core-infra`), PR 5 (`feat/base-agent`), PR 8 (`feat/planner-graph`), PR 9 (`feat/api-switch`)  ·  **Reviews:** PR 10, PR 11

**PR 1 — Repository hygiene and CI.** Files: `.gitignore`, `.gitattributes`, `.env.example`, `requirements*.txt`, `pytest.ini`, `.github/workflows/tests.yml`

- Why the generated `test_report_*.html` files, unused `services/price_service.py` (it returned a fake price of 500) and old logs were removed.
- Pinned versions make Render and CI install exactly what was tested; `.env.example` lists keys without values so no secret is committed.
- CI: `.github/workflows/tests.yml` runs pytest on every push and PR; `pytest.ini` puts the repo root on the import path.

**PR 2 — Core infrastructure: config, LLM client, tracer, memory.** Files: `config.py`, `services/llm_service.py`, `core/tracer.py`, `core/memory.py`, `core/context.py`, `legacy/` (temporary)

- Why the old pipeline moved to `legacy/`: the app keeps working while new agents are built under the same names; it is deleted in PR 9.
- `LLMClient.structured`: sends a Pydantic schema as Gemini's response schema, validates the JSON, retries once, and returns an error instead of raising.
- The free-tier `RateLimiter`: a sliding 60-second window (`GEMINI_RPM`); when it is full the call fails and the agent uses its rule fallback.
- The tracer: every message gets run_id, seq, from, to, type, round, payload and LLM metadata; written per run to `logs/traces/<run_id>.jsonl` and pushed to listeners (the live stream).
- Run memory: SQLite table of past runs per user and ticker, read by the Planner.

**PR 5 — BaseAgent: LLM decisions with rule fallback and a tool loop.** Files: `agents/base.py`, `tests/fakes.py`, `tests/agent_helpers.py`

- `BaseAgent.decide`: one structured LLM decision, or the rule fallback with the agent marked degraded.
- `BaseAgent.tool_loop` (ReAct style): the LLM sees the tool list and every earlier result/failure, picks the next tool; it stops as soon as the goal is met (saves free-tier calls); without an LLM it follows a default order.
- `FakeLLM`: scripted answers per (agent, schema), so every agentic path is tested offline.

**PR 8 — Planner and LangGraph orchestration.** Files: `agents/planner_agent.py`, `core/graph.py`, `core/runner.py`, `tests/test_agent_paths.py`

- Why LangGraph: conditional edges after `assess` (retry / proceed / abort) and after `review` (approve / revise / arbitrate). Show `route_after_assess` and `route_after_review`.
- Planner decisions: plan with per-analyst instructions, assess and re-plan once, cap confidence, arbitrate after 3 rounds; guardrails: MarketAnalyst is mandatory, a vetoed BUY cannot be final.
- Analysts run in parallel in a thread pool inside the `analysts` node; errors become messages to the Planner, never crashes.
- Model choice: Planner / Strategy / Risk use the reasoning model, the others the fast model.

**PR 9 — Serve the agent graph from the API and retire the CA2 pipeline.** Files: `app.py`, `tests/test_api.py` (and deleting `legacy/`)

- `/api/analyze/stream`: the analysis runs in a thread; the tracer pushes each message into a queue; Flask streams them as Server-Sent Events, with keep-alives every 15 s.
- Validation returns 400 with the failing field; no price data returns 502 with a clear message; any agent bug is logged and returns a clean error.
- Security: `SECRET_KEY` from the environment, salted `generate_password_hash`, old SHA-256 accounts upgraded on login, `REQUIRE_LOGIN` switch.

### Member 2

**Pull requests:** PR 4 (`feat/data-tools`), PR 6 (`feat/analyst-agents`)  ·  **Reviews:** PR 3, PR 5, PR 7

**PR 4 — Data tools: prices, indicators, fundamentals, news.** Files: `tools/base.py`, `tools/market_data.py`, `tools/indicators.py`, `tools/fundamentals_data.py`, `tools/news_data.py`, `tools/portfolio_analyzer.py` (moved), `tests/conftest.py`

- Tools fetch and calculate; agents decide. That is why the LLM cannot invent a price or an RSI.
- Free source order and quotas: yfinance (no key) → Alpha Vantage (25/day) → MarketStack (100/month, http only); 15-minute cache.
- RSI(14), daily volatility, MA20 vs MA50 trend with a ±0.5% band.
- The CA2 sentiment bug ("refinery" matched "fine") and the whole-word regex that fixes it.

**PR 6 — Market, Fundamentals and News analyst agents.** Files: `agents/market_agent.py`, `agents/fundamentals_agent.py`, `agents/news_agent.py`

- Market analyst: the LLM chooses the price source, sees failures, switches; indicators come from the tool; the LLM interprets them.
- Fundamentals analyst: real ratios + rule score, LLM judges relative to sector; missing data is reported, never guessed.
- News analyst: picks a news source, the LLM labels each headline's sentiment and materiality; keyword scorer if the LLM is down.

### Member 3

**Pull requests:** PR 3 (`feat/decision-core`), PR 7 (`feat/committee-agents`)  ·  **Reviews:** PR 2, PR 4, PR 8

**PR 3 — Typed schemas and risk / position maths.** Files: `core/schemas.py`, `tools/risk_rules.py`, `tools/position.py`

- Why every LLM decision has a typed schema: objections always have ids, drafts always say which ids they answered, verdicts can only be approve/revise/veto.
- Request validation: ticker regex and suffix stripping, age 18–100, enums for the dropdowns.
- Suitability gap: stock risk minus a tolerance derived from the investor's capacity; positive means riskier than this investor should hold.
- Position sizing: 2–8% of the real portfolio by capacity, capped by the Profile limit, zero on HOLD/SELL; targets scale with volatility.

**PR 7 — Profile, Risk, Strategy, Portfolio and Report agents.** Files: `agents/profile_agent.py`, `agents/risk_agent.py`, `agents/strategy_agent.py`, `agents/portfolio_agent.py`, `agents/report_agent.py`

- Profile agent: turns a free-text goal into constraints and a max position %, clamped to 15%.
- Risk manager: approve / revise / veto with objections; the G1 guardrail overrides an LLM approval of a BUY with suitability gap > 15.
- Strategy agent: must answer each objection id; its confidence is capped by the Planner's data-quality assessment.
- Portfolio and Report agents: sizing from the real portfolio value; the report explains where the agents disagreed.

### Member 4

**Pull requests:** PR 10 (`feat/live-agent-ui`), PR 11 (`docs/submission`)  ·  **Reviews:** PR 1, PR 6, PR 9

**PR 10 — Live agent conversation in the UI.** Files: `frontend/index.html`, `frontend/css/app.css`, `frontend/js/app.js`

- Why the old UI was a problem: a hard-coded price table and a 5-second timeout silently replaced the agents' result.
- The live feed: `fetch` + `ReadableStream` parsing SSE events `start`, `trace`, `result`; each message rendered with sender → receiver, type, round, and LLM/fallback badge.
- Result panels: analyst findings, round-by-round debate, report, run footer; all text escaped with `esc()` (XSS-safe).

**PR 11 — JSON Schemas, documentation and deployment.** Files: `schemas/*.json`, `tests/test_schemas.py`, `docs/*`, `README.md`, `render.yaml`, `scripts/capture_run.py`

- How docs stay consistent with code: `tests/test_schemas.py` validates real output against `schemas/analyze_response.schema.json`.
- The orchestration pattern (orchestrator–worker + critic loop) and why it beats a single agent here.
- Render free tier: `render.yaml`, one gunicorn worker with 8 threads for streaming; why evidence traces are committed (free disk is wiped).

