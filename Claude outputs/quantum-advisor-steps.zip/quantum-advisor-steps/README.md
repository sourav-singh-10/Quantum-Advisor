# quantum-advisor-steps

Prepared, tested steps that turn the CA2 Quantum Advisor into the CA3 multi-agent system.

- `START_HERE.md` — read this first: Git and GitHub in plain words, and the 3 buttons to click.
- `do_pr.py` — one command per pull request; does all the git work.
- `TEAM_PLAN.md` — who does what, in which order, how to commit / push / open and review PRs, and what each member must be able to explain.
- `apply_step.py` — applies one step's file changes to your clone. It never commits or pushes; you review, test and commit yourself.
- `steps/NN-*/` — the exact files for each step (`step.json` lists moves, deletions, the commit message and the expected test result).

Keep this folder **next to** your repo clone, not inside it.
