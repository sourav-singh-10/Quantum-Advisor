"""Apply one prepared step to your clone of the repo, then YOU review, test and commit it.

Usage (run from inside your repo folder):
    python ..\quantum-advisor-steps\apply_step.py 05

It only changes files (git mv / git rm / copies). It never commits or pushes.
"""
import glob
import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: python apply_step.py <step number>")
    num = int(sys.argv[1])
    matches = sorted((HERE / "steps").glob(f"{num:02d}-*"))
    if not matches:
        sys.exit(f"no step {num}")
    step_dir = matches[0]
    step = json.loads((step_dir / "step.json").read_text(encoding="utf-8"))
    repo = Path.cwd()
    if not (repo / ".git").exists():
        sys.exit("run this from the root of your quantum-advisor clone")
    if HERE in repo.parents or repo == HERE:
        sys.exit("keep quantum-advisor-steps OUTSIDE the repo folder")
    branch = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True).stdout.strip()
    if branch != step["branch"]:
        print(f"WARNING: you are on '{branch}', this step belongs on '{step['branch']}'.")
        if input("Continue anyway? [y/N] ").lower() != "y":
            sys.exit(1)

    for old, new in step["rename"]:
        (repo / new).parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(["git", "mv", old, new], check=True)
    for path in step["delete"]:
        subprocess.run(["git", "rm", "-q", "-r", "--ignore-unmatch", path], check=True)
    for pattern in step.get("delete_globs", []):
        for path in glob.glob(pattern):
            subprocess.run(["git", "rm", "-q", "--ignore-unmatch", path], check=True)
    for f in step["files"]:
        dst = repo / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(step_dir / "files" / f, dst)

    print(f"\nStep {num} applied: {len(step['files'])} file(s) written, "
          f"{len(step['rename'])} moved, {len(step['delete'])} deleted.")
    print("\nNow:")
    print("  1. git status   and   git diff     <- read every change; you must be able to explain it")
    print("  2. python -m pytest -q                    <- expected: " + step["expected_tests"])
    print("  3. git add -A")
    print(f'  4. git commit -m "{step["message"]}"')


if __name__ == "__main__":
    main()
